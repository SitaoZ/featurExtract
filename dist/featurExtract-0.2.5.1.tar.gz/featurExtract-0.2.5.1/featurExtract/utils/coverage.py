import pysam 
import pandas as pd 

# step1 
# UTR5 CDS UTR length 



# step2 bam 


# step3 plot coverage in transcript

 
